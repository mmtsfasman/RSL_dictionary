HamNoSys2HPSG v. 2.1
Holding the option key when clicking on the Visia button now opens a window with the SiGML content to be sent. This can be edited and then sent by clicking on the Visia button in that window.
Empty SiGML windows can also be opened from the menu bar (cmd-N).

HamNoSys2HPSG v. 2.0
Now uses HamNoSysUnicode instead of HamNoSys font. This eliminates the needs for the decimal and octal column in the chart.
The Visia socket now outputs SiGML instead of HNST.


HamNoSys2HPSG v. 1.2
In order to avoid encoding problems, layout.txt now contains HamNoSys tokens instead of byte values. That means if you have custom layout files, some twiddling is needed.


HamNoSys2HPSG v. 1.1
Added Magnification to palette window. First line of layout.txt contains the factor the original size is multiplied with. Distribution value is 1.5. If you have customised layout.txt from previous versions: The new format is changed only by adding a new line with a single number at the beginning of the file.

HamNoSys2HPSG v. 1.0.5
Added a table showing symbols and names in HamNoSys as well as their ascii codes in decimal, octal, and hexadecimal. Table can be sorted by clicking on the headers.

HamNoSys2HPSG v. 1.0.4
Added the "V!" button to ask Visia to sign the contents of the lower (!) text edit field of the main window. Visia's address is read in from a text file called "VisiaIPAddress.txt".

HamNoSys2HPSG v. 1.0.1
Added read-in of a textfile specifying the separators to be used in the conversion from HamNoSys strings to HPSG values.
1st line: prefix of string
2nd line: infix to separate items
3rd line: suffix of string
The file name is HamNoSysSeparators.txt. The file included in the distribution reflects the value useful for Lingo TDL.


HamNoSys2HPSG v. 1

The HamNoSys2HPSG utilities shall facilitate working with HamNoSys in the context of HPSG environments that normally simply ignore fonts and therefore cannot display feature values appropriately. Therefore this utility can convert back and forth between HamNoSys strings and ASCII representations. The ASCII representation of a HamNoSys symbol is its name as defined in the SiGML context.
In the upper field you can type in HamNoSys characters. By clicking the downwards arrow button, you will get the textual representation. Alternatively, you can manipulate a textual representation and then click the upwards arrow button to get the HamNoSys string.
To paste text from other applications, click the left of the right arrow buttons. To copy text into the clipboard to transfer it to other applications, click the right of the right arrow buttons.
By clicking on the "..." button, you will get an input palette to facilitate the HamNoSys input. (You can open more than one palette by repeatly clicking on the button.)

Apparently, this applications requires the HamNoSys 4 font to be installed. A cross-compilation to Windows is available, but has not been thoroughly tested. In the Win version, automatic keyboard switching upon entering or leaving the HamNosys text input field is not available.

The font included in this package is pre-release. It still has a number of rendering problems as well as some Mac-Win compatibility problems. However, the compatibility problems will not affect the HamNoSys2HPSG utility as HamNoSys text is not stored.

Files included in this release:
ReadMe.txt - this text
HamNoSys2HPSG Mac - the Mac version of the utility
HamNoSys2HPSG.exe - the Win version of the utility
HAMNP___.TTF - the Win version of the HamNoSys TrueType font
HamnosysPlain - the Mac version of the HamNoSys TrueType font
HamNoSys - the HamNoSys script and keyboard for the Mac (install this before you install the font)
Layout.txt - see below
HamSymbols.txt - the mapping from (Mac) character codes to character names

You may customize the input palettes by editing the accompanying text file "layout.txt". It is a tab-text file with four columns:
1. number of the palette tab the button shall appear in (1...6)
2. x offset from top left corner of tab in pixels
3. y offset from top left corner of tab in pixels
4. HamNoSys string to appear as button caption as well as the input to the HamNosys text field when the button is clicked.

Please note: The files "layout.txt" and "HamSymbols.txt" need to reside in the same folder as the application.

If you find any bugs or would like to see some bits added, please let me know: mailto:thomas.hanke@sign-lang.uni-hamburg.de.