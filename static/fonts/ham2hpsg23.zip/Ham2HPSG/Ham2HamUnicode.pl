open(IN,"HamSymbols.txt") || die "no input file for Ham2HamUnicode";
while(<IN>) {
	chop;
	split(/\t/);
	if ($_[2]) {
		my $x=chr($_[0]);
		if ($unicodeequivalents{$x}) {
			print STDERR "double assignment for $x\n";
		}
		$unicodeequivalents{$x}=$_[2];
	}
}
close(IN);

while(<>) {
	chop;
	$_=Ham2Unicode($_);
	print "$_\n"
}

sub Ham2Unicode {
	my $input=shift;
	my @chars=split(//);
	my $output="";
	for ($i=0;$i<@chars;$i++) {
		if ($unicodeequivalents{$chars[$i]}) {
			$output.="<0x$unicodeequivalents{$chars[$i]}>"
		} else {
			print STDERR "No substitution for $chars[$i] in $_\n"
		}
	}
	return $output
}
