This package introduces a new HamNoSys font to be used in MacOS X and Win XP, named HamNoSysUnicode.

This version of the font is not intended to be distributed widely, instead it shall only be used internally at UH as well as in the eSIGN project.
The reason is that compatibility with programs is low (in my unverified opinion due to limited Unicode support in most applications), so the encoding might be changed once again if incompatibilities can be reduced that way. Please only store formats based on HamNoSys tokens, not characters.
HamNoSysUnicode is not usable under MacOS earlier than MacOS X, but due to the different name it can co-exist with the older versions to be used in Classic apps. Please note that full installation under MacOS X v. 10 and 10.1 is really a nightmare, so I strongly recommend to only use it with 10.2 or later.

The Win version is supposed to run under XP and probably 2000. It does not work under 95/98 due to limited Unicode support, and for ME please try yourselves.

The new font eliminates a number of rendering problems the older 4.0 versions had. There are still a number of Open Type definitions to be added for optimal diacritics placement.

If you have to convert larger text quantities from HamNoSys to HamNoSysUnicode, this is pretty much straightforward e.g. with Perl making use of the file HamSymbols.txt which contains:
1st column: character number (decimal) in old encoding
2nd column: token name of character
3rd column: character number (hex) in new encoding.
(4th column: encoding used in file names e.g. for handshape drawings)
A sample Perl script is contained in the distribution.

(At this point of time, a converter script to change Mac Word documents is not that useful, because Word belongs to those programs not fully Unicode-supportive on the Mac.)

How to install on MAC OS X:
* Put the font into your favourite fonts folder. (As we experienced some rendering problems when installing it into the network or system Library folder, we recommend to install into the user's Library folder.)
* Put the keyboard file and the associated icon file into one of the Library/Keyboard\ Layouts folders.
* Open the International system preference, switch to Keyboard Menu and mark the HamNoSys layout to be used. You can now toggle between your standard Roman keyboard (German, British, or whatever) and HamNoSys.

Please note that HamNoSys belongs to the Unicode (126) script. It is therefore only active for applications that declare themselves Unicode-ready, and unfortunately there are not too many. Some more applications can render Unicode once it has found its way into the document, e.g. Adobe Indesign via Tag-Text Import.

In cases where you do not use Ham2HPSG to input HamNoSys characters, it might be useful to open the Character Palette from the Keyboard menu. (If there is no "Show Character Palette" command, go to "Customize Menu�" and mark the Character Palette in the list of available "keyboards". In the palette, select "HamNoSysUnicode" in the font menu and either view by Unicode Blocks and select "Private Use Area" (almost at the end) or by Unicode Table or by Glyphs Table.



How to install on WIN XP:
* Just drag the font file into the Fonts folder.

Currently, there is no HamNoSys keyboard for Windows. Please use Insert Character functions (or decimal input) unless you work with Ham2HPSG.



This distribution includes Ham2HPSG in a new version that makes use of the new font. In addition, it deals with a number of bugs introduced with the change of compiler in version 1.5.

